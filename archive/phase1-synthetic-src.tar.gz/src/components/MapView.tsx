import { Canvas } from '@react-three/fiber';
import { useRef } from 'react';
import { Scene } from '../scene/Scene';
import { useStore, useViewStore } from '../state/store';
import { FullscreenIcon } from './Icons';

function Compass() {
  const azimuth = useViewStore((s) => s.azimuth);
  return (
    <div className="compass" title="North">
      <span className="compass__n">N</span>
      <svg viewBox="0 0 40 40" width="40" height="40" style={{ transform: `rotate(${azimuth}deg)` }}>
        <circle cx="20" cy="20" r="17" fill="rgba(40,38,34,.72)" stroke="rgba(255,255,255,.5)" />
        <path d="M20 7l6 19-6-4-6 4z" fill="#fff" />
      </svg>
    </div>
  );
}

function MapControls({ containerRef }: { containerRef: React.RefObject<HTMLDivElement> }) {
  const viewMode = useStore((s) => s.viewMode);
  const setViewMode = useStore((s) => s.setViewMode);
  const zoom = useViewStore((s) => s.zoom);
  const fullscreen = () => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen();
  };
  return (
    <div className="map-controls">
      <div className="scalebar">
        <div className="scalebar__labels"><span>0</span><span>0.5</span><span>1 km</span></div>
        <div className="scalebar__bar" />
      </div>
      <div className="segmented">
        {(['2d', '3d'] as const).map((m) => (
          <button key={m} className={viewMode === m ? 'is-active' : ''} onClick={() => setViewMode(m)}>
            {m.toUpperCase()}
          </button>
        ))}
      </div>
      <span className="zoom-readout">{zoom.toFixed(1)}×</span>
      <button className="icon-btn" onClick={fullscreen} aria-label="Fullscreen">
        <FullscreenIcon />
      </button>
    </div>
  );
}

export function MapView() {
  const ref = useRef<HTMLDivElement>(null);
  return (
    <section className="map" ref={ref}>
      <Canvas dpr={[1, 2]} gl={{ antialias: true }}>
        <Scene />
      </Canvas>
      <Compass />
      <MapControls containerRef={ref} />
    </section>
  );
}
