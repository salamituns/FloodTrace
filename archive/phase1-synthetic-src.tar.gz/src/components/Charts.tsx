import { useMemo, type ReactNode } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  ReferenceDot,
  ReferenceLine,
  ResponsiveContainer,
  XAxis,
  YAxis,
} from 'recharts';
import { areaAt, areaKm2 } from '../data/flood';
import { FLOOD_STAGE, rainAt, stageAt } from '../data/hydrology';
import { DURATION_H, fmtDay, tAtHour } from '../lib/time';
import { useQuantTime } from '../state/store';

interface Row {
  t: number;
  area: number;
  stage: number;
  rain: number;
}

const ROWS: Row[] = Array.from({ length: DURATION_H + 1 }, (_, h) => {
  const t = tAtHour(h);
  return { t, area: areaKm2[h], stage: stageAt(t), rain: rainAt(t) };
});
const DAY_TICKS = [18, 42, 66, 90].map(tAtHour); // midnights
const AXIS = { fontSize: 10, fill: '#8a8378' };
const DOMAIN: [number, number] = [ROWS[0].t, ROWS[ROWS.length - 1].t];

/** Rows with the series split into a solid "past" part and a faded "future" part at the cursor. */
function useSplit(key: 'area' | 'stage', t: number) {
  return useMemo(
    () =>
      ROWS.map((r) => ({
        t: r.t,
        past: r.t <= t + 3_600_000 ? r[key] : null,
        future: r.t >= t - 3_600_000 ? r[key] : null,
      })),
    [key, t],
  );
}

function ChartCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="chart">
      <header className="chart__head">
        <h4>{title}</h4>
        <span className="kebab">⋮</span>
      </header>
      <div className="chart__body">
        <ResponsiveContainer width="100%" height="100%">
          {children as React.ReactElement}
        </ResponsiveContainer>
      </div>
    </section>
  );
}

const xAxis = <XAxis dataKey="t" type="number" domain={DOMAIN} ticks={DAY_TICKS} tickFormatter={fmtDay} tick={AXIS} tickLine={false} axisLine={{ stroke: '#d6d0c5' }} />;

export function Charts() {
  const t = useQuantTime();
  const area = useSplit('area', t);
  const stage = useSplit('stage', t);

  return (
    <div className="charts">
      <ChartCard title="Inundated Area (km²)">
        <AreaChart data={area} margin={{ top: 6, right: 10, bottom: 0, left: -18 }}>
          <CartesianGrid vertical={false} stroke="#ece7de" />
          {xAxis}
          <YAxis tick={AXIS} tickLine={false} axisLine={false} width={44} />
          <Area dataKey="future" stroke="#7aa6c6" strokeDasharray="3 3" fill="#cfe0ec" fillOpacity={0.5} isAnimationActive={false} connectNulls={false} />
          <Area dataKey="past" stroke="#1f5f8b" strokeWidth={1.6} fill="#6f9fc4" fillOpacity={0.55} isAnimationActive={false} connectNulls={false} />
          <ReferenceLine x={t} stroke="#2b2824" />
          <ReferenceDot x={t} y={areaAt(t)} r={3.5} fill="#fff" stroke="#2b2824" />
        </AreaChart>
      </ChartCard>

      <ChartCard title="River Stage, CF-01 (m)">
        <LineChart data={stage} margin={{ top: 6, right: 10, bottom: 0, left: -18 }}>
          <CartesianGrid vertical={false} stroke="#ece7de" />
          {xAxis}
          <YAxis tick={AXIS} tickLine={false} axisLine={false} width={44} domain={[0, 8]} ticks={[0, 2, 4, 6, 8]} />
          <ReferenceLine y={FLOOD_STAGE} stroke="#d4452f" strokeDasharray="4 3" label={{ value: 'Flood stage', position: 'insideTopRight', fontSize: 9, fill: '#d4452f' }} />
          <Line dataKey="future" stroke="#9db6c8" strokeDasharray="3 3" dot={false} isAnimationActive={false} connectNulls={false} />
          <Line dataKey="past" stroke="#1f5f8b" strokeWidth={1.8} dot={false} isAnimationActive={false} connectNulls={false} />
          <ReferenceLine x={t} stroke="#2b2824" />
          <ReferenceDot x={t} y={stageAt(t)} r={3.5} fill="#fff" stroke="#2b2824" />
        </LineChart>
      </ChartCard>

      <ChartCard title="Rainfall (mm/h)">
        <BarChart data={ROWS} margin={{ top: 6, right: 10, bottom: 0, left: -18 }} barCategoryGap={0.5}>
          <CartesianGrid vertical={false} stroke="#ece7de" />
          {xAxis}
          <YAxis tick={AXIS} tickLine={false} axisLine={false} width={44} />
          <Bar dataKey="rain" isAnimationActive={false}>
            {ROWS.map((r) => (
              <Cell key={r.t} fill={r.t <= t ? '#4a7fb5' : '#c9d8e6'} />
            ))}
          </Bar>
          <ReferenceLine x={t} stroke="#2b2824" />
        </BarChart>
      </ChartCard>
    </div>
  );
}
