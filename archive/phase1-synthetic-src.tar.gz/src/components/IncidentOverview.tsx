import { areaKm2 } from '../data/flood';
import { EVENTS } from '../data/events';
import { T1, fmtDateTime } from '../lib/time';

const peakArea = Math.max(...areaKm2);
const breach = EVENTS.find((e) => e.id === 'breach')!;

const ROWS: [string, string][] = [
  ['Incident Name', 'Cedar Fork Flood'],
  ['Incident ID', 'TN-CFR-2026-0042'],
  ['Location', 'Cedar Fork Valley, TN'],
  ['Start (Est.)', `${fmtDateTime(EVENTS[0].t)}, 2026`],
  ['End', `${fmtDateTime(T1)}, 2026`],
  ['Breach', fmtDateTime(breach.t)],
  ['Peak Inundation', `${peakArea.toFixed(1)} km²`],
  ['Cause (Prelim.)', 'Levee breach (piping)'],
];

export function IncidentOverview() {
  return (
    <section className="card">
      <header className="card__head">
        <h3>Incident Overview</h3>
        <button className="link-btn">Edit</button>
      </header>
      <dl className="kv">
        {ROWS.map(([k, v]) => (
          <div key={k}>
            <dt>{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
        <div>
          <dt>Analysis Status</dt>
          <dd><span className="status-dot" /> In Progress</dd>
        </div>
      </dl>
    </section>
  );
}
