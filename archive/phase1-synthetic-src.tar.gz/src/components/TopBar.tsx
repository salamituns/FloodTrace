import { fmtDay } from '../lib/time';
import { T0, T1 } from '../lib/time';
import { CalendarIcon, ChartIcon, Chevron, DroneIcon, GearIcon, LogoMark, MapIcon, ShareIcon, TruckIcon, ViewIcon } from './Icons';

export function TopBar() {
  return (
    <header className="topbar">
      <div className="brand">
        <LogoMark />
        <span className="brand__name">FloodTrace</span>
        <span className="brand__sub">Flood Forensic Analysis</span>
      </div>
      <span className="topbar__sep" />
      <button className="incident-select">
        Cedar Fork Flood <Chevron />
      </button>
      <span className="topbar__muted">Cedar Fork Valley, TN</span>
      <span className="topbar__date">
        <CalendarIcon /> {fmtDay(T0)} – {fmtDay(T1)}, 2026
      </span>

      <nav className="modes" aria-label="Mode">
        <button className="mode mode--active" aria-pressed="true">
          <MapIcon /> Incident
        </button>
        <button className="mode" disabled title="Coming in phase 2">
          <DroneIcon /> Drones <span className="badge">6</span>
        </button>
        <button className="mode" disabled title="Coming in phase 3">
          <TruckIcon /> Resources <span className="badge">9</span>
        </button>
      </nav>

      <div className="topbar__menus">
        <button className="menu"><ViewIcon /> View <Chevron /></button>
        <button className="menu"><ChartIcon /> Analysis <Chevron /></button>
        <button className="menu"><ShareIcon /> Share <Chevron /></button>
        <button className="menu menu--icon" aria-label="Settings"><GearIcon /></button>
      </div>
    </header>
  );
}
