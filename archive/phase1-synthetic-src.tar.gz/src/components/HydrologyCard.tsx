import type { ReactNode } from 'react';
import { BREACH, depthAt, flowVelocity, type FlowSample } from '../data/flood';
import { FLOOD_STAGE, dischargeAt, rainAt, saturationAt, stageAt } from '../data/hydrology';
import { BUILDINGS } from '../data/places';
import { useQuantTime } from '../state/store';
import { DropIcon, GaugeIcon, HouseIcon, ArrowIcon, RainIcon, WaveIcon } from './Icons';

const sample: FlowSample = { vx: 0, vz: 0, depth: 0 };

function Metric({ icon, label, value, unit, sub, danger }: { icon: ReactNode; label: string; value: string; unit: string; sub?: string; danger?: boolean }) {
  return (
    <div className={`metric ${danger ? 'metric--danger' : ''}`}>
      <span className="metric__icon">{icon}</span>
      <div>
        <div className="metric__label">{label}</div>
        <div className="metric__value">
          {value} <span className="metric__unit">{unit}</span>
        </div>
        {sub && <div className="metric__sub">{sub}</div>}
      </div>
    </div>
  );
}

export function HydrologyCard() {
  const t = useQuantTime();
  const rain = rainAt(t);
  const stage = stageAt(t);
  const q = dischargeAt(t);
  const sat = saturationAt(t);
  const townDepth = BUILDINGS.reduce((m, b) => Math.max(m, depthAt(b.x, b.z, t)), 0);
  const velocity = flowVelocity(BREACH.x + 60, BREACH.z + 20, t, sample) ? Math.hypot(sample.vx, sample.vz) : 0;
  const delta = stage - FLOOD_STAGE;

  return (
    <section className="card">
      <header className="card__head">
        <h3>Hydrology &amp; Flood Behavior <span className="card__hint">(gauge CF-01)</span></h3>
      </header>
      <div className="metrics">
        <Metric icon={<RainIcon />} label="Rainfall" value={rain.toFixed(1)} unit="mm/h" danger={rain > 25} />
        <Metric
          icon={<GaugeIcon />}
          label="River stage"
          value={stage.toFixed(2)}
          unit="m"
          sub={`${delta >= 0 ? '+' : ''}${delta.toFixed(2)} vs flood stage`}
          danger={delta > 0}
        />
        <Metric icon={<WaveIcon />} label="Discharge" value={Math.round(q).toLocaleString()} unit="m³/s" danger={q > 240} />
        <Metric icon={<DropIcon />} label="Soil saturation" value={sat.toFixed(0)} unit="%" danger={sat > 85} />
        <Metric icon={<HouseIcon />} label="Max depth, Millbrook" value={townDepth.toFixed(2)} unit="m" danger={townDepth > 0.6} />
        <Metric icon={<ArrowIcon />} label="Flow at breach" value={velocity.toFixed(1)} unit="m/s" danger={velocity > 1.5} />
      </div>
    </section>
  );
}
