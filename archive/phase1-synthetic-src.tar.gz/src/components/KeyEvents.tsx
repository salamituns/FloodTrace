import { EVENTS, EVENT_COLORS, type EventKind } from '../data/events';
import { fmtDateTime } from '../lib/time';
import { useQuantTime, useStore } from '../state/store';

function EventGlyph({ kind }: { kind: EventKind }) {
  const c = EVENT_COLORS[kind];
  switch (kind) {
    case 'breach':
      return <svg viewBox="0 0 14 14" width="14" height="14"><path d="M7 1l6 12H1z" fill={c} /></svg>;
    case 'evac':
      return <svg viewBox="0 0 14 14" width="14" height="14"><rect x="1.5" y="1.5" width="11" height="11" rx="2" fill={c} /><path d="M5 7h5M8 4.5L10.5 7 8 9.5" stroke="#fff" strokeWidth="1.4" fill="none" /></svg>;
    case 'crest':
      return <svg viewBox="0 0 14 14" width="14" height="14"><path d="M1 12L7 2l6 10z" fill="none" stroke={c} strokeWidth="2" /></svg>;
    case 'rain':
      return <svg viewBox="0 0 14 14" width="14" height="14"><path d="M7 1C4.5 5 3 6.8 3 8.8a4 4 0 008 0C11 6.8 9.5 5 7 1z" fill={c} /></svg>;
    default:
      return <svg viewBox="0 0 14 14" width="14" height="14"><circle cx="7" cy="7" r="5.5" fill={c} /></svg>;
  }
}

export function KeyEvents() {
  const t = useQuantTime();
  const selected = useStore((s) => s.selectedEventId);
  const { setTime, selectEvent, setPlaying } = useStore.getState();
  return (
    <section className="events">
      <header className="events__head">
        <h3>Key Events</h3>
        <button className="add-btn">+ Add</button>
      </header>
      <ul>
        {EVENTS.map((ev) => (
          <li key={ev.id}>
            <button
              className={`event ${selected === ev.id ? 'is-selected' : ''} ${ev.t > t ? 'is-future' : ''}`}
              onClick={() => {
                setPlaying(false);
                setTime(ev.t);
                selectEvent(ev.id);
              }}
            >
              <EventGlyph kind={ev.kind} />
              <span className="event__name">{ev.name}</span>
              <span className="event__time">{fmtDateTime(ev.t)}</span>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
