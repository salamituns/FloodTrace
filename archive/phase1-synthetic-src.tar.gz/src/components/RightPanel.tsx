import { useState } from 'react';
import { HydrologyCard } from './HydrologyCard';
import { IncidentOverview } from './IncidentOverview';
import { LayersPanel } from './LayersPanel';

const TABS = ['Layers', 'Analysis', 'Evidence', 'Notes'] as const;

export function RightPanel() {
  const [tab, setTab] = useState<(typeof TABS)[number]>('Layers');
  return (
    <aside className="right">
      <section className="card card--tabs">
        <nav className="tabs" role="tablist">
          {TABS.map((t) => (
            <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? 'is-active' : ''} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </nav>
        {tab === 'Layers' ? <LayersPanel /> : <p className="empty">{tab} arrives in a later phase.</p>}
      </section>
      <IncidentOverview />
      <HydrologyCard />
    </aside>
  );
}
