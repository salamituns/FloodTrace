import { useRef, useState, type PointerEvent } from 'react';
import { EVENTS, EVENT_COLORS } from '../data/events';
import { DURATION_H, T0, T1, fmtClock, fmtDateTime, fmtDay, tAtHour } from '../lib/time';
import { useStore } from '../state/store';
import { PauseIcon, PlayIcon, StepIcon } from './Icons';

const TICKS = Array.from({ length: DURATION_H / 6 + 1 }, (_, i) => tAtHour(i * 6));
const frac = (t: number) => (t - T0) / (T1 - T0);

export function Timeline() {
  const t = useStore((s) => s.currentTime);
  const playing = useStore((s) => s.playing);
  const speed = useStore((s) => s.speed);
  const { setTime, togglePlay, cycleSpeed, setPlaying, selectEvent } = useStore.getState();
  const track = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState<number | null>(null);

  const timeAt = (clientX: number) => {
    const r = track.current!.getBoundingClientRect();
    const f = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
    return T0 + f * (T1 - T0);
  };
  const onDown = (e: PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    setPlaying(false);
    selectEvent(null);
    setTime(timeAt(e.clientX));
  };
  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    setHover(timeAt(e.clientX));
    if (e.currentTarget.hasPointerCapture(e.pointerId)) setTime(timeAt(e.clientX));
  };
  const stepToNextEvent = () => {
    const next = EVENTS.find((ev) => ev.t > t + 60_000);
    setPlaying(false);
    if (next) {
      setTime(next.t);
      selectEvent(next.id);
    } else setTime(T1);
  };

  return (
    <section className="timeline">
      <header className="timeline__head">
        <h3>Timeline</h3>
        <span className="timeline__range">
          {fmtDateTime(T0)} – {fmtDateTime(T1)}
        </span>
      </header>
      <div className="timeline__body">
        <div className="transport">
          <button className="icon-btn" onClick={togglePlay} aria-label={playing ? 'Pause' : 'Play'}>
            {playing ? <PauseIcon /> : <PlayIcon />}
          </button>
          <button className="icon-btn" onClick={stepToNextEvent} aria-label="Next event">
            <StepIcon />
          </button>
          <button className="speed" onClick={cycleSpeed} title="Simulation hours per second">
            {speed}×
          </button>
        </div>
        <div className="scrubber">
          <div
            className="scrubber__track"
            ref={track}
            onPointerDown={onDown}
            onPointerMove={onMove}
            onPointerLeave={() => setHover(null)}
          >
            <div className="scrubber__rail" />
            <div className="scrubber__fill" style={{ width: `${frac(t) * 100}%` }} />
            {EVENTS.map((ev) => (
              <span
                key={ev.id}
                className={`scrubber__event scrubber__event--${ev.kind}`}
                style={{ left: `${frac(ev.t) * 100}%`, color: EVENT_COLORS[ev.kind] }}
                title={`${ev.name} · ${fmtDateTime(ev.t)}`}
              />
            ))}
            <div className="scrubber__thumb" style={{ left: `${frac(t) * 100}%` }}>
              <span className="scrubber__bubble">{fmtDateTime(t)}</span>
            </div>
            {hover !== null && (
              <span className="scrubber__hover" style={{ left: `${frac(hover) * 100}%` }}>
                {fmtDateTime(hover)}
              </span>
            )}
          </div>
          <div className="scrubber__ticks">
            {TICKS.map((tick) => {
              const midnight = fmtClock(tick) === '00:00';
              return (
                <span key={tick} style={{ left: `${frac(tick) * 100}%` }} className={midnight || tick === T0 ? 'is-day' : ''}>
                  <b>{midnight || tick === T0 ? fmtDay(tick) : ' '}</b>
                  {fmtClock(tick)}
                </span>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
