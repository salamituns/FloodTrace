import { useEffect } from 'react';
import { Charts } from './components/Charts';
import { KeyEvents } from './components/KeyEvents';
import { MapView } from './components/MapView';
import { RightPanel } from './components/RightPanel';
import { Timeline } from './components/Timeline';
import { TopBar } from './components/TopBar';
import { HOUR, T1 } from './lib/time';
import { useStore } from './state/store';

/** The single clock: advances currentTime while playing. Everything else only reads it. */
function useClockDriver() {
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      const { playing, speed, currentTime, setTime, setPlaying } = useStore.getState();
      if (playing) {
        const next = currentTime + dt * speed * HOUR;
        setTime(next);
        if (next >= T1) setPlaying(false);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);
}

export default function App() {
  useClockDriver();
  return (
    <div className="app">
      <TopBar />
      <main className="workspace">
        <MapView />
        <div className="bottom">
          <Timeline />
          <Charts />
          <KeyEvents />
        </div>
      </main>
      <RightPanel />
    </div>
  );
}
