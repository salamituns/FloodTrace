// Local metres ↔ geographic coordinates around a fictional Cedar Fork Valley, TN.
const LAT0 = 36.12;
const LON0 = -86.95;
const M_PER_DEG_LAT = 111_000;
const M_PER_DEG_LON = 111_000 * Math.cos((LAT0 * Math.PI) / 180);

export const latOf = (z: number) => LAT0 - z / M_PER_DEG_LAT;
export const lonOf = (x: number) => LON0 + x / M_PER_DEG_LON;
export const zOfLat = (lat: number) => (LAT0 - lat) * M_PER_DEG_LAT;
export const xOfLon = (lon: number) => (lon - LON0) * M_PER_DEG_LON;

function dm(v: number): string {
  const a = Math.abs(v);
  const deg = Math.floor(a);
  return `${deg}°${((a - deg) * 60).toFixed(1).padStart(4, '0')}′`;
}

export const fmtLat = (lat: number) => `${dm(lat)}N`;
export const fmtLon = (lon: number) => `${dm(lon)}W`;
