// Incident clock. All times are epoch ms, formatted in incident-local time (stored as UTC fields).
export const HOUR = 3_600_000;
export const T0 = Date.UTC(2026, 2, 3, 6, 0); // Mar 3 2026 06:00
export const DURATION_H = 96;
export const T1 = T0 + DURATION_H * HOUR; // Mar 7 2026 06:00

// UI panels that don't need frame-accurate time re-render on this grid.
export const QUANT = 15 * 60_000;

export const tAtHour = (h: number) => T0 + h * HOUR;
export const hourOf = (t: number) => (t - T0) / HOUR;

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const p2 = (n: number) => String(n).padStart(2, '0');

export function fmtDay(t: number): string {
  const d = new Date(t);
  return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}`;
}

export function fmtClock(t: number): string {
  const d = new Date(t);
  return `${p2(d.getUTCHours())}:${p2(d.getUTCMinutes())}`;
}

export function fmtDateTime(t: number): string {
  return `${fmtDay(t)}, ${fmtClock(t)}`;
}
