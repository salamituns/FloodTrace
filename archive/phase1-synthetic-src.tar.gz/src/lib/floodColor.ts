export interface DepthStyle {
  /** RGB, each 0–1 */
  color: [number, number, number];
  /** 0–1, multiplied by the Flood Depth layer opacity */
  alpha: number;
}

/**
 * Colour for a given flood depth in metres. Used for the water surface everywhere
 * (sampled into a lookup table at startup) and to tint flooded buildings.
 */
export function depthToColor(depthM: number): DepthStyle {
  // TODO(user): map depth bands to colours. Typical hazard thresholds:
  //   ~0.15 m ankle-deep (nuisance) · ~0.6 m stalls/floats vehicles · ~1.5 m life-threatening.
  //   Decide whether deeper water reads as darker blue, or switches to warning hues,
  //   and whether very shallow water should fade out (low alpha) at the shoreline.
  void depthM;
  return { color: [0.25, 0.5, 0.75], alpha: 0.6 };
}

// Precomputed so the per-frame water update allocates nothing.
export const LUT_STEP = 0.02;
export const LUT_MAX = 6;
const LUT_SIZE = Math.round(LUT_MAX / LUT_STEP) + 1;
export const depthLUT = new Float32Array(LUT_SIZE * 4);
for (let i = 0; i < LUT_SIZE; i++) {
  const { color, alpha } = depthToColor(i * LUT_STEP);
  depthLUT.set([color[0], color[1], color[2], alpha], i * 4);
}

export const lutIndex = (depthM: number) => Math.min(LUT_SIZE - 1, Math.round(depthM / LUT_STEP)) * 4;
