import { DURATION_H, hourOf, tAtHour } from '../lib/time';
import { BREACH_H, eastStageAt, stageAt } from './hydrology';
import { BREACH_Z, LEVEE_D, N, SPACING, baseElev, gridZ, heights, riverDX, riverX, sampleHeight, signedD, gridX } from './terrain';

export const BREACH = { x: riverX(BREACH_Z) + LEVEE_D, z: BREACH_Z };

/** How far the breach outflow has travelled (m). */
export function frontRadius(h: number): number {
  return h < BREACH_H ? 0 : 3200 * (1 - Math.exp(-(h - BREACH_H) / 5));
}

/**
 * Water surface elevation (m). West bank and channel follow the river stage (bathtub);
 * the levee-protected east floodplain only fills after the breach, within the advancing front.
 */
function surface(d: number, z: number, distB: number, h: number, S: number, E: number): number {
  const bed = baseElev(z) - 4;
  if (d < LEVEE_D - 25) return bed + S;
  const hasEast = E === E && distB <= frontRadius(h);
  if (d > LEVEE_D + 15) return hasEast ? bed + E : -Infinity;
  // On the levee itself: only the breach gap carries water.
  if (h >= BREACH_H && distB < 120) return bed + (hasEast ? Math.max(S, E) : S);
  return -Infinity;
}

export function waterSurfaceAt(x: number, z: number, t: number): number {
  const d = x - riverX(z);
  const distB = Math.hypot(x - BREACH.x, z - BREACH.z);
  return surface(d, z, distB, hourOf(t), stageAt(t), eastStageAt(t));
}

export function depthAt(x: number, z: number, t: number): number {
  return Math.max(0, waterSurfaceAt(x, z, t) - sampleHeight(x, z));
}

// Only vertices low enough to ever flood are evaluated each frame.
const cand: number[] = [];
for (let i = 0; i < N * N; i++) {
  const z = gridZ(Math.floor(i / N));
  if (heights[i] < baseElev(z) - 4 + 8.2) cand.push(i);
}
export const candidates = Int32Array.from(cand);
const cD = new Float32Array(candidates.length);
const cZ = new Float32Array(candidates.length);
const cDist = new Float32Array(candidates.length);
for (let k = 0; k < candidates.length; k++) {
  const i = candidates[k];
  const x = gridX(i % N);
  const z = gridZ(Math.floor(i / N));
  cD[k] = signedD[i];
  cZ[k] = z;
  cDist[k] = Math.hypot(x - BREACH.x, z - BREACH.z);
}

/** Fill per-candidate depth (m) and an edge fade (0–1) at the advancing breach front. */
export function computeDepths(t: number, depth: Float32Array, fade: Float32Array): void {
  const h = hourOf(t);
  const S = stageAt(t);
  const E = eastStageAt(t);
  const R = frontRadius(h);
  for (let k = 0; k < candidates.length; k++) {
    const wse = surface(cD[k], cZ[k], cDist[k], h, S, E);
    const dd = wse - heights[candidates[k]];
    depth[k] = dd > 0 ? dd : 0;
    fade[k] = cD[k] > LEVEE_D + 15 ? Math.min(1, Math.max(0, (R - cDist[k]) / 200)) : 1;
  }
}

// Hourly inundated area + per-vertex maximum depth over the whole incident.
const CELL_KM2 = (SPACING * SPACING) / 1e6;
export const areaKm2 = new Float32Array(DURATION_H + 1);
export const maxDepth = new Float32Array(N * N);
{
  const depth = new Float32Array(candidates.length);
  const fade = new Float32Array(candidates.length);
  for (let hk = 0; hk <= DURATION_H; hk++) {
    computeDepths(tAtHour(hk), depth, fade);
    let wet = 0;
    for (let k = 0; k < candidates.length; k++) {
      const dd = depth[k];
      if (dd > 0.05) wet++;
      const i = candidates[k];
      if (dd > maxDepth[i]) maxDepth[i] = dd;
    }
    areaKm2[hk] = wet * CELL_KM2;
  }
}

export const areaAt = (t: number) => {
  const h = Math.min(DURATION_H, Math.max(0, hourOf(t)));
  const i = Math.min(DURATION_H - 1, Math.floor(h));
  return areaKm2[i] + (areaKm2[i + 1] - areaKm2[i]) * (h - i);
};

export interface FlowSample {
  vx: number;
  vz: number;
  depth: number;
}

/** Surface flow velocity (m/s). Returns false where it is dry. */
export function flowVelocity(x: number, z: number, t: number, out: FlowSample): boolean {
  const d = x - riverX(z);
  const distB = Math.hypot(x - BREACH.x, z - BREACH.z);
  const h = hourOf(t);
  const S = stageAt(t);
  const E = eastStageAt(t);
  const depth = surface(d, z, distB, h, S, E) - sampleHeight(x, z);
  if (!(depth > 0.05)) return false;
  out.depth = depth;
  if (d < LEVEE_D - 25) {
    const tx = riverDX(z);
    const n = Math.hypot(tx, 1);
    const sp = (0.5 + 0.3 * S) * Math.max(0.15, 1 - Math.abs(d) / 700);
    out.vx = (tx / n) * sp;
    out.vz = (1 / n) * sp;
  } else {
    // Out through the breach while the river is higher, back towards it while draining.
    const filling = S > E + 0.05;
    const sp = filling ? 0.25 + 2.2 * Math.exp(-distB / 700) : 0.15 + 0.4 * Math.exp(-distB / 900);
    const sign = filling ? 1 : -1;
    const n = Math.max(1, distB);
    out.vx = (sign * (x - BREACH.x)) / n * sp;
    out.vz = (sign * (z - BREACH.z)) / n * sp + 0.08;
  }
  return true;
}
