import { mulberry32 } from '../lib/noise';
import { HALF, N, gridX, gridZ, heights, riverX, sampleHeight } from './terrain';

export type XZ = [number, number];

export const TOWN = { x: riverX(250) + 650, z: 250 };
export const GAUGE = { x: riverX(-2200), z: -2200 };

function highestIn(x0: number, x1: number, z0: number, z1: number) {
  let best = { x: 0, z: 0, h: -Infinity };
  for (let row = 0; row < N; row++) {
    const z = gridZ(row);
    if (z < z0 || z > z1) continue;
    for (let col = 0; col < N; col++) {
      const x = gridX(col);
      if (x < x0 || x > x1) continue;
      const h = heights[row * N + col];
      if (h > best.h) best = { x, z, h };
    }
  }
  return best;
}

export const PEAKS = [
  { name: 'Kettle Knob', ...highestIn(-4200, -1600, -3200, 200) },
  { name: 'Bald Ridge', ...highestIn(1800, 4200, 600, 3800) },
];

export interface Building {
  x: number;
  z: number;
  w: number;
  d: number;
  h: number;
  rot: number;
}

export const BUILDINGS: Building[] = (() => {
  const rng = mulberry32(42);
  const out: Building[] = [];
  let tries = 0;
  while (out.length < 72 && tries++ < 4000) {
    const a = rng() * Math.PI * 2;
    const r = Math.sqrt(rng()) * 430;
    const x = TOWN.x + Math.cos(a) * r * 1.2;
    const z = TOWN.z + Math.sin(a) * r;
    if (x - riverX(z) < 260) continue; // stay off the levee
    if (out.some((b) => Math.hypot(b.x - x, b.z - z) < 62)) continue;
    out.push({ x, z, w: 30 + rng() * 18, d: 24 + rng() * 14, h: 9 + rng() * 6, rot: 0.35 + (rng() - 0.5) * 0.3 });
  }
  return out;
})();

const range = (a: number, b: number, step: number) => {
  const out: number[] = [];
  for (let v = a; v <= b; v += step) out.push(v);
  return out;
};

/** SR-41 runs along the east floodplain; a county road crosses the river on a bridge. */
export const ROADS: XZ[][] = [
  range(-HALF, HALF, 60).map((z): XZ => [riverX(z) + 420 + 140 * Math.sin(z / 2000), z]),
  range(-1600, 420 + 140 * Math.sin(1500 / 2000) + 1, 40).map((dx): XZ => [riverX(1500) + dx, 1500]),
];

export const ADMIN_BOUNDARY: XZ[] = range(-HALF, HALF, 100).map((x): XZ => [x, -2600 + x * 0.18 + 120 * Math.sin(x / 700)]);

/** Sandbag lines placed on the breach-facing side of Millbrook. */
export const SANDBAG_DEPLOY_H = 17; // Mar 3 23:00
export const SANDBAGS: XZ[][] = [
  range(-2.55, -1.75, 0.04).map((a): XZ => [TOWN.x + Math.cos(a) * 470, TOWN.z + Math.sin(a) * 470]),
  range(2.35, 3.05, 0.04).map((a): XZ => [TOWN.x + Math.cos(a) * 480, TOWN.z + Math.sin(a) * 480]),
];

/** Lift 2D points onto the terrain surface (metres). */
export function drape(points: XZ[], offset: number): [number, number, number][] {
  return points.map(([x, z]) => [x, sampleHeight(x, z) + offset, z]);
}
