import { fbm, smoothstep } from '../lib/noise';

// World is in metres: x east, z south, y up. The river flows north → south (+z).
export const SIZE = 10_000;
export const HALF = SIZE / 2;
export const N = 321; // vertices per side
export const SPACING = SIZE / (N - 1);

// Render transform: metres → scene units, with vertical exaggeration.
export const S = 0.01;
export const VEX = 2;

export const CHANNEL_HALF_W = 60;
export const LEVEE_D = 92; // levee crest distance east of the river centreline
export const LEVEE_H = 3.5;
export const BREACH_Z = -150;

export function riverX(z: number): number {
  return 320 * Math.sin(z / 1100) + 140 * Math.sin(z / 430 + 1.3);
}

export function riverDX(z: number): number {
  return (320 / 1100) * Math.cos(z / 1100) + (140 / 430) * Math.cos(z / 430 + 1.3);
}

/** Floodplain elevation at the river centreline (valley floor slopes downstream). */
export function baseElev(z: number): number {
  return 180 - 0.008 * (z + HALF);
}

/** 0 on the floodplain → 1 in the hills. */
export function hillFactor(d: number): number {
  const ad = Math.abs(d);
  return d < 0 ? smoothstep(650, 1800, ad) : smoothstep(1150, 2300, ad);
}

function leveeBump(d: number, z: number): number {
  const k = 1 - ((d - LEVEE_D) / 26) ** 2;
  if (k <= 0) return 0;
  const gap = smoothstep(40, 95, Math.abs(z - BREACH_Z)); // the breach scar
  return LEVEE_H * k * gap;
}

export function computeHeight(x: number, z: number): number {
  const d = x - riverX(z);
  const ad = Math.abs(d);
  const channel = ad < CHANNEL_HALF_W ? -4 * (1 - (ad / CHANNEL_HALF_W) ** 2) : 0;
  const rise = d < 0 ? 0.0045 * ad : 0.0026 * ad;
  const undulation = 0.9 * (fbm(x / 380, z / 380, 3, 3) - 0.5) * smoothstep(CHANNEL_HALF_W, 150, ad);
  const t = hillFactor(d);
  const hills = t * (40 + 560 * fbm(x / 1700 + 11, z / 1700 - 7, 5, 1) ** 1.6) + t * 30 * (fbm(x / 280, z / 280, 3, 2) - 0.5);
  const levee = d > 0 ? leveeBump(d, z) : 0;
  return baseElev(z) + channel + rise + undulation + hills + levee;
}

export const gridX = (col: number) => -HALF + col * SPACING;
export const gridZ = (row: number) => -HALF + row * SPACING;

// Precomputed height + signed distance-to-river grids (row-major, row = z).
export const heights = new Float32Array(N * N);
export const signedD = new Float32Array(N * N);
for (let row = 0; row < N; row++) {
  const z = gridZ(row);
  const rx = riverX(z);
  for (let col = 0; col < N; col++) {
    const x = gridX(col);
    const i = row * N + col;
    heights[i] = computeHeight(x, z);
    signedD[i] = x - rx;
  }
}

/** Shared triangle index for every grid-aligned mesh (terrain, water, overlays). */
export const gridIndex = (() => {
  const idx = new Uint32Array((N - 1) * (N - 1) * 6);
  let k = 0;
  for (let row = 0; row < N - 1; row++) {
    for (let col = 0; col < N - 1; col++) {
      const a = row * N + col;
      const b = a + 1;
      const c = a + N;
      const d = c + 1;
      idx[k++] = a;
      idx[k++] = c;
      idx[k++] = b;
      idx[k++] = b;
      idx[k++] = c;
      idx[k++] = d;
    }
  }
  return idx;
})();

/** Bilinear height lookup — cheap enough for per-frame use. */
export function sampleHeight(x: number, z: number): number {
  const fc = Math.min(N - 1.001, Math.max(0, (x + HALF) / SPACING));
  const fr = Math.min(N - 1.001, Math.max(0, (z + HALF) / SPACING));
  const c = Math.floor(fc);
  const r = Math.floor(fr);
  const u = fc - c;
  const v = fr - r;
  const i = r * N + c;
  const h00 = heights[i];
  const h10 = heights[i + 1];
  const h01 = heights[i + N];
  const h11 = heights[i + N + 1];
  return h00 + (h10 - h00) * u + (h01 - h00) * v + (h00 - h10 - h01 + h11) * u * v;
}
