import { DURATION_H, HOUR, T0 } from '../lib/time';

// Gauge CF-01 stage is measured from the channel bed; bankfull = flood stage.
export const FLOOD_STAGE = 4.0;
export const LEVEE_CREST_STAGE = 7.5;
export const BREACH_H = 21 + 40 / 60; // Mar 4 03:40

export const STEP_H = 0.25;
export const NS = DURATION_H / STEP_H + 1;

const g = (h: number, c: number, w: number) => Math.exp(-(((h - c) / w) ** 2));

function rainfallRate(h: number): number {
  if (h < 2) return 0;
  const r = 38 * g(h, 14, 4) + 52 * g(h, 20, 3.5) + 14 * g(h, 27, 5) + 3 * g(h, 40, 8);
  return r < 0.3 ? 0 : r;
}

function riverStage(h: number): number {
  return 2.2 + 5.0 * g(h, 39, h < 39 ? 22 : 44.5);
}

export const rain = new Float32Array(NS);
export const cumRain = new Float32Array(NS);
export const stage = new Float32Array(NS);
export const discharge = new Float32Array(NS);
export const saturation = new Float32Array(NS);
/** Water level behind the levee (same datum as stage); NaN before the breach. */
export const eastStage = new Float32Array(NS);

{
  let cum = 0;
  let east = NaN;
  for (let i = 0; i < NS; i++) {
    const h = i * STEP_H;
    rain[i] = rainfallRate(h);
    if (i > 0) cum += 0.5 * (rain[i] + rain[i - 1]) * STEP_H;
    cumRain[i] = cum;
    const s = riverStage(h);
    stage[i] = s;
    discharge[i] = 28 * Math.max(0, s - 0.6) ** 1.65;
    saturation[i] = Math.min(99, 42 + 55 * (1 - Math.exp(-cum / 80)) - 0.15 * Math.max(0, h - 40));

    // Fill fast through the breach, drain slowly back out of the protected floodplain.
    if (h >= BREACH_H) {
      if (Number.isNaN(east)) east = FLOOD_STAGE;
      const sub = 5;
      for (let k = 0; k < sub; k++) {
        const sh = riverStage(h - STEP_H + ((k + 1) * STEP_H) / sub);
        const rate = sh > east ? 0.45 : 0.06;
        east += rate * (sh - east) * (STEP_H / sub);
      }
    }
    eastStage[i] = east;
  }
}

export function sampleSeries(arr: Float32Array, t: number): number {
  const x = Math.min(NS - 1, Math.max(0, (t - T0) / HOUR / STEP_H));
  const i = Math.min(NS - 2, Math.floor(x));
  const f = x - i;
  return arr[i] + (arr[i + 1] - arr[i]) * f;
}

export const stageAt = (t: number) => sampleSeries(stage, t);
export const eastStageAt = (t: number) => sampleSeries(eastStage, t);
export const rainAt = (t: number) => sampleSeries(rain, t);
export const dischargeAt = (t: number) => sampleSeries(discharge, t);
export const saturationAt = (t: number) => sampleSeries(saturation, t);
