import { tAtHour } from '../lib/time';
import { BREACH } from './flood';
import { BREACH_H } from './hydrology';
import { GAUGE, TOWN } from './places';

export type EventKind = 'rain' | 'breach' | 'evac' | 'crest' | 'recession' | 'clear';

export interface FloodEvent {
  id: string;
  name: string;
  kind: EventKind;
  t: number;
  x: number;
  z: number;
}

export const EVENT_COLORS: Record<EventKind, string> = {
  rain: '#4a7fb5',
  breach: '#d4452f',
  evac: '#e58a2b',
  crest: '#1d4f7a',
  recession: '#5f8f6a',
  clear: '#7f8a93',
};

export const EVENTS: FloodEvent[] = [
  { id: 'rain', name: 'Rain onset', kind: 'rain', t: tAtHour(2), ...GAUGE },
  { id: 'breach', name: 'Levee breach', kind: 'breach', t: tAtHour(BREACH_H), ...BREACH },
  { id: 'evac', name: 'Evacuation order', kind: 'evac', t: tAtHour(22.25), ...TOWN },
  { id: 'crest', name: 'Peak crest', kind: 'crest', t: tAtHour(39), ...GAUGE },
  { id: 'recession', name: 'Recession begins', kind: 'recession', t: tAtHour(48), ...TOWN },
  { id: 'clear', name: 'Below flood stage', kind: 'clear', t: tAtHour(84), ...GAUGE },
];
