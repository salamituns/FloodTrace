import { OrbitControls, OrthographicCamera, PerspectiveCamera } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import { useRef } from 'react';
import * as THREE from 'three';
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib';
import { BREACH } from '../data/flood';
import { TOWN } from '../data/places';
import { S, VEX, baseElev } from '../data/terrain';
import { useStore, useViewStore } from '../state/store';
import { Buildings } from './Buildings';
import { FloodPath } from './FloodPath';
import { FlowVectors } from './FlowVectors';
import { Grid2D } from './Grid2D';
import { Labels } from './Labels';
import { AdminBoundaries, Defenses, Roads } from './Linework';
import { Overlays } from './Overlays';
import { Terrain } from './Terrain';
import { Vegetation } from './Vegetation';
import { Water } from './Water';

const SKY = '#dde0de';
// Frame the breach and the town it flooded.
const FOCUS_X = ((BREACH.x + TOWN.x) / 2) * S;
const FOCUS_Z = ((BREACH.z + TOWN.z) / 2) * S;
const TARGET: [number, number, number] = [FOCUS_X, baseElev(0) * S * VEX, FOCUS_Z];
const CAM_3D: [number, number, number] = [TARGET[0] - 25, TARGET[1] + 19, TARGET[2] + 17];
const INITIAL_DIST = Math.hypot(CAM_3D[0] - TARGET[0], CAM_3D[1] - TARGET[1], CAM_3D[2] - TARGET[2]);
const ORTHO_ZOOM = 16;

/** Publishes compass heading + zoom factor for the HTML map controls. */
function ViewTracker() {
  const controls = useThree((s) => s.controls) as OrbitControlsImpl | null;
  const camera = useThree((s) => s.camera);
  const last = useRef({ zoom: 0, azimuth: 0 });
  useFrame(() => {
    if (!controls) return;
    const azimuth = THREE.MathUtils.radToDeg(controls.getAzimuthalAngle());
    const zoom =
      camera instanceof THREE.OrthographicCamera
        ? (camera.zoom / ORTHO_ZOOM) * 2
        : (INITIAL_DIST / camera.position.distanceTo(controls.target)) * 2.5;
    if (Math.abs(zoom - last.current.zoom) > 0.05 || Math.abs(azimuth - last.current.azimuth) > 0.5) {
      last.current = { zoom, azimuth };
      useViewStore.setState({ zoom, azimuth });
    }
  });
  return null;
}

export function Scene() {
  const viewMode = useStore((s) => s.viewMode);
  const is3d = viewMode === '3d';
  return (
    <>
      <color attach="background" args={[SKY]} />
      {is3d && <fog attach="fog" args={[SKY, 45, 130]} />}
      <hemisphereLight args={['#fffaf0', '#6b5d48', 1.1]} />
      <directionalLight position={[-30, 45, 15]} intensity={1.8} />

      {is3d ? (
        <PerspectiveCamera makeDefault fov={38} near={0.1} far={400} position={CAM_3D} />
      ) : (
        <OrthographicCamera makeDefault near={0.1} far={2000} zoom={ORTHO_ZOOM} position={[TARGET[0], 60, TARGET[2] + 0.001]} />
      )}
      <OrbitControls
        key={viewMode}
        makeDefault
        target={TARGET}
        enableRotate={is3d}
        enableDamping
        dampingFactor={0.12}
        maxPolarAngle={is3d ? 1.42 : 0}
        minDistance={3}
        maxDistance={95}
        minZoom={6}
        maxZoom={120}
        screenSpacePanning={!is3d}
      />
      <ViewTracker />

      <group scale={[S, S * VEX, S]}>
        <Terrain />
        <Overlays />
        <Water />
        <Vegetation />
        <Buildings />
        <Defenses />
        <Roads />
        <AdminBoundaries />
        <FloodPath />
        <FlowVectors />
        <Labels />
        {!is3d && <Grid2D />}
      </group>
    </>
  );
}
