import { useMemo } from 'react';
import * as THREE from 'three';
import { fbm, smoothstep } from '../lib/noise';
import { CHANNEL_HALF_W, N, SPACING, gridIndex, gridX, gridZ, heights, hillFactor, signedD } from '../data/terrain';
import { useStore } from '../state/store';

const FIELDS = ['#a9a77a', '#b4ad80', '#a1a173', '#bcb18a', '#9c9e6c', '#b2a67d'].map((c) => new THREE.Color(c));
const HILL = new THREE.Color('#c2ab80');
const HILL_STEEP = new THREE.Color('#9b8761');
const HILL_HIGH = new THREE.Color('#b8a98a');
const MUD = new THREE.Color('#8a806c');
const PLAIN = new THREE.Color('#d8d3ca');

/** Shared positions for grid-aligned meshes: terrain height + a vertical offset (m). */
export function gridPositions(offset: number): Float32Array {
  const pos = new Float32Array(N * N * 3);
  for (let i = 0; i < N * N; i++) {
    pos[i * 3] = gridX(i % N);
    pos[i * 3 + 1] = heights[i] + offset;
    pos[i * 3 + 2] = gridZ(Math.floor(i / N));
  }
  return pos;
}

export const sharedIndex = new THREE.BufferAttribute(gridIndex, 1);

function slopeAt(i: number): number {
  const col = i % N;
  const row = Math.floor(i / N);
  const l = heights[row * N + Math.max(0, col - 1)];
  const r = heights[row * N + Math.min(N - 1, col + 1)];
  const u = heights[Math.max(0, row - 1) * N + col];
  const d = heights[Math.min(N - 1, row + 1) * N + col];
  return Math.hypot(r - l, d - u) / (2 * SPACING);
}

function buildColors(imagery: boolean): Float32Array {
  const col = new Float32Array(N * N * 3);
  const c = new THREE.Color();
  for (let i = 0; i < N * N; i++) {
    const x = gridX(i % N);
    const z = gridZ(Math.floor(i / N));
    const d = signedD[i];
    const slope = slopeAt(i);
    if (!imagery) {
      c.copy(PLAIN).multiplyScalar(1 - Math.min(0.25, slope * 0.6));
    } else {
      // Patchwork fields on the floodplain, earthy scrub on the hills.
      const fx = Math.floor((x * 0.94 + z * 0.34) / 260);
      const fz = Math.floor((z * 0.94 - x * 0.34) / 200);
      const field = FIELDS[Math.abs((fx * 7 + fz * 13) % FIELDS.length)];
      c.copy(field).multiplyScalar(0.94 + 0.12 * fbm(x / 90, z / 90, 2, 5));
      const t = hillFactor(d);
      if (t > 0) {
        const hill = HILL.clone().lerp(HILL_STEEP, Math.min(1, slope * 2.2)).lerp(HILL_HIGH, smoothstep(380, 560, heights[i]));
        c.lerp(hill, t);
      }
      c.lerp(MUD, 1 - smoothstep(CHANNEL_HALF_W * 0.6, CHANNEL_HALF_W * 1.3, Math.abs(d)));
    }
    col[i * 3] = c.r;
    col[i * 3 + 1] = c.g;
    col[i * 3 + 2] = c.b;
  }
  return col;
}

export function Terrain() {
  const terrain = useStore((s) => s.layers.terrain);
  const imagery = useStore((s) => s.layers.imagery);

  const { geometry, imageryColors, plainColors } = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(gridPositions(0), 3));
    g.setIndex(sharedIndex);
    g.computeVertexNormals();
    const imageryColors = buildColors(true);
    const plainColors = buildColors(false);
    g.setAttribute('color', new THREE.BufferAttribute(imageryColors.slice(), 3));
    return { geometry: g, imageryColors, plainColors };
  }, []);

  // Aerial imagery opacity blends between the photo-like palette and a neutral hillshade.
  useMemo(() => {
    const attr = geometry.getAttribute('color') as THREE.BufferAttribute;
    const out = attr.array as Float32Array;
    const k = imagery.visible ? imagery.opacity : 0;
    for (let i = 0; i < out.length; i++) out[i] = plainColors[i] + (imageryColors[i] - plainColors[i]) * k;
    attr.needsUpdate = true;
  }, [geometry, imageryColors, plainColors, imagery.visible, imagery.opacity]);

  return (
    <mesh geometry={geometry} visible={terrain.visible} renderOrder={0}>
      <meshStandardMaterial
        vertexColors
        flatShading
        roughness={1}
        metalness={0}
        transparent={terrain.opacity < 1}
        opacity={terrain.opacity}
      />
    </mesh>
  );
}
