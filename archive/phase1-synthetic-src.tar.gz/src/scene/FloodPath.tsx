import { Html, Line } from '@react-three/drei';
import { useMemo } from 'react';
import * as THREE from 'three';
import { BREACH, depthAt, frontRadius } from '../data/flood';
import { BREACH_H } from '../data/hydrology';
import { TOWN, drape, type XZ } from '../data/places';
import { fmtDateTime, hourOf, tAtHour } from '../lib/time';
import { useQuantTime, useStore } from '../state/store';

const BASE_ANGLE = Math.atan2(TOWN.z - BREACH.z, TOWN.x - BREACH.x);
const WAYPOINT_HOURS = [BREACH_H, 26, 31, 39];

/** Leading edge of the breach outflow at time t: march out from the breach while still wet. */
function frontPoint(t: number): XZ {
  const h = hourOf(t);
  const a = BASE_ANGLE + 0.35 * Math.min(1, Math.max(0, (h - BREACH_H) / 17)); // bends downstream over time
  const dx = Math.cos(a);
  const dz = Math.sin(a);
  const R = frontRadius(h);
  let reach = 0;
  for (let s = 0; s <= R; s += 25) {
    if (s > 150 && depthAt(BREACH.x + dx * s, BREACH.z + dz * s, t) < 0.02) break;
    reach = s;
  }
  return [BREACH.x + dx * reach, BREACH.z + dz * reach];
}

function smoothPath(points: XZ[]): XZ[] {
  if (points.length < 2) return points;
  const curve = new THREE.CatmullRomCurve3(points.map(([x, z]) => new THREE.Vector3(x, 0, z)));
  return curve.getPoints(points.length * 16).map((v): XZ => [v.x, v.z]);
}

const WAYPOINTS = WAYPOINT_HOURS.map((h) => ({ t: tAtHour(h), p: frontPoint(tAtHour(h)) }));

export function FloodPath() {
  const visible = useStore((s) => s.layers.depth.visible);
  const t = useQuantTime();
  const full = useMemo(() => drape(smoothPath(WAYPOINTS.map((w) => w.p)), 4), []);
  const past = useMemo(() => {
    if (hourOf(t) < BREACH_H) return null;
    const pts = WAYPOINTS.filter((w) => w.t <= t).map((w) => w.p);
    if (t < WAYPOINTS[WAYPOINTS.length - 1].t) pts.push(frontPoint(t));
    return pts.length >= 2 ? drape(smoothPath(pts), 5) : null;
  }, [t]);

  if (!visible) return null;
  return (
    <group>
      <Line points={full} color="#f2c14e" lineWidth={2.4} dashed dashSize={60} gapSize={45} />
      {past && <Line points={past} color="#e2572b" lineWidth={4} />}
      {WAYPOINTS.map((w, i) => {
        const [x, z] = w.p;
        const [pos] = drape([[x, z]], 6);
        const reached = t >= w.t;
        return (
          <Html key={i} position={pos} center zIndexRange={[20, 0]} style={{ pointerEvents: 'none' }}>
            <div className={`pin ${reached ? '' : 'pin--future'} ${i === 0 ? 'pin--origin' : ''}`}>
              <span className="pin__dot" />
              <span className="pin__label">
                {i === 0 && <strong>Levee breach</strong>}
                {fmtDateTime(w.t)}
              </span>
            </div>
          </Html>
        );
      })}
    </group>
  );
}
