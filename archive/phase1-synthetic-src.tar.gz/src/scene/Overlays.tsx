import { useMemo } from 'react';
import * as THREE from 'three';
import { maxDepth } from '../data/flood';
import { N, baseElev, gridZ, heights } from '../data/terrain';
import { useStore, type LayerId } from '../state/store';
import { gridPositions, sharedIndex } from './Terrain';

type Rgba = [number, number, number, number];

function overlayGeometry(offset: number, colorAt: (i: number) => Rgba | null): THREE.BufferGeometry {
  const col = new Float32Array(N * N * 4);
  for (let i = 0; i < N * N; i++) {
    const c = colorAt(i);
    if (c) col.set(c, i * 4);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(gridPositions(offset), 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 4));
  g.setIndex(sharedIndex);
  g.computeVertexNormals();
  return g;
}

function Overlay({ layerId, geometry, renderOrder }: { layerId: LayerId; geometry: THREE.BufferGeometry; renderOrder: number }) {
  const layer = useStore((s) => s.layers[layerId]);
  return (
    <mesh geometry={geometry} visible={layer.visible} renderOrder={renderOrder}>
      <meshLambertMaterial
        vertexColors
        transparent
        opacity={layer.opacity}
        depthWrite={false}
        polygonOffset
        polygonOffsetFactor={-2}
      />
    </mesh>
  );
}

const EXTENT: Rgba = [0.36, 0.5, 0.62, 0.38];
const SUSC: Rgba[] = [
  [0.84, 0.29, 0.23, 0.55],
  [0.91, 0.54, 0.23, 0.45],
  [0.91, 0.77, 0.35, 0.35],
];

export function Overlays() {
  const { extent, susceptibility } = useMemo(
    () => ({
      // Everything that was ever wet during the incident — the flood's "scar".
      extent: overlayGeometry(0.3, (i) => (maxDepth[i] > 0.05 ? EXTENT : null)),
      // Height above the floodplain datum: a simple relative-elevation susceptibility proxy.
      susceptibility: overlayGeometry(0.35, (i) => {
        const hand = heights[i] - baseElev(gridZ(Math.floor(i / N)));
        if (hand < 0.8) return SUSC[0];
        if (hand < 2) return SUSC[1];
        if (hand < 3.5) return SUSC[2];
        return null;
      }),
    }),
    [],
  );
  return (
    <>
      <Overlay layerId="maxExtent" geometry={extent} renderOrder={1} />
      <Overlay layerId="susceptibility" geometry={susceptibility} renderOrder={2} />
    </>
  );
}
