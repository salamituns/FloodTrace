import { Html } from '@react-three/drei';
import type { ReactNode } from 'react';
import { GAUGE, PEAKS, TOWN, drape } from '../data/places';
import { riverX } from '../data/terrain';
import { useStore } from '../state/store';

function Label({ x, z, lift, children, className = '' }: { x: number; z: number; lift: number; children: ReactNode; className?: string }) {
  const [pos] = drape([[x, z]], lift);
  return (
    <Html position={pos} center zIndexRange={[15, 0]} style={{ pointerEvents: 'none' }}>
      <div className={`place ${className}`}>{children}</div>
    </Html>
  );
}

export function Labels() {
  const structures = useStore((s) => s.layers.structures.visible);
  return (
    <group>
      {structures && (
        <Label x={TOWN.x} z={TOWN.z - 520} lift={20} className="place--town">
          Millbrook
          <small>pop. 4,180</small>
        </Label>
      )}
      <Label x={GAUGE.x} z={GAUGE.z} lift={12} className="place--gauge">
        <span className="gauge-icon">◉</span> Gauge CF-01
      </Label>
      <Label x={riverX(-3600) - 160} z={-3600} lift={8} className="place--river">
        Cedar Fork River
      </Label>
      {PEAKS.map((p) => (
        <Label key={p.name} x={p.x} z={p.z} lift={25}>
          ▲ {p.name}
          <small>{Math.round(p.h)} m</small>
        </Label>
      ))}
    </group>
  );
}
