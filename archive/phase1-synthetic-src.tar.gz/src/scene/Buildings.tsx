import { useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { depthAt } from '../data/flood';
import { BUILDINGS } from '../data/places';
import { VEX, sampleHeight } from '../data/terrain';
import { depthLUT, lutIndex } from '../lib/floodColor';
import { useStore } from '../state/store';

const DRY = new THREE.Color('#ece6da');

export function Buildings() {
  const visible = useStore((s) => s.layers.structures.visible);
  const ref = useRef<THREE.InstancedMesh>(null);
  const geometry = useMemo(() => new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), []);

  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const up = new THREE.Vector3(0, 1, 0);
    BUILDINGS.forEach((b, i) => {
      q.setFromAxisAngle(up, b.rot);
      m.compose(new THREE.Vector3(b.x, sampleHeight(b.x, b.z) - 0.5, b.z), q, new THREE.Vector3(b.w, (b.h * 1.4) / VEX, b.d));
      mesh.setMatrixAt(i, m);
      mesh.setColorAt(i, DRY);
    });
    mesh.instanceMatrix.needsUpdate = true;
  }, []);

  // Tint each structure by the flood depth at its footprint.
  useEffect(() => {
    const c = new THREE.Color();
    const tint = new THREE.Color();
    const paint = (t: number) => {
      const mesh = ref.current;
      if (!mesh) return;
      BUILDINGS.forEach((b, i) => {
        const d = depthAt(b.x, b.z, t);
        c.copy(DRY);
        if (d > 0.05) {
          const li = lutIndex(d);
          tint.setRGB(depthLUT[li], depthLUT[li + 1], depthLUT[li + 2]);
          c.lerp(tint, Math.min(0.85, 0.35 + d * 0.3));
        }
        mesh.setColorAt(i, c);
      });
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    };
    paint(useStore.getState().currentTime);
    return useStore.subscribe((s, prev) => {
      if (s.currentTime !== prev.currentTime) paint(s.currentTime);
    });
  }, []);

  return (
    <instancedMesh ref={ref} args={[geometry, undefined, BUILDINGS.length]} visible={visible} frustumCulled={false}>
      <meshStandardMaterial flatShading roughness={0.85} />
    </instancedMesh>
  );
}
