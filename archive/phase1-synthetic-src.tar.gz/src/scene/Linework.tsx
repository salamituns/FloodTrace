import { Line } from '@react-three/drei';
import { useMemo } from 'react';
import { ADMIN_BOUNDARY, ROADS, SANDBAGS, SANDBAG_DEPLOY_H, drape, type XZ } from '../data/places';
import { BREACH_Z, HALF, LEVEE_D, riverX } from '../data/terrain';
import { hourOf } from '../lib/time';
import { useQuantTime, useStore } from '../state/store';

function leveeSegments(): XZ[][] {
  const north: XZ[] = [];
  const south: XZ[] = [];
  for (let z = -HALF; z <= HALF; z += 40) {
    if (Math.abs(z - BREACH_Z) < 70) continue;
    (z < BREACH_Z ? north : south).push([riverX(z) + LEVEE_D, z]);
  }
  return [north, south];
}

export function Defenses() {
  const layer = useStore((s) => s.layers.defenses);
  const t = useQuantTime();
  const levee = useMemo(() => leveeSegments().map((s) => drape(s, 1.2)), []);
  const sandbags = useMemo(() => SANDBAGS.map((s) => drape(s, 1.5)), []);
  if (!layer.visible) return null;
  const deployed = hourOf(t) >= SANDBAG_DEPLOY_H;
  return (
    <group>
      {levee.map((pts, i) => (
        <Line key={i} points={pts} color="#6e5236" lineWidth={2.2} transparent opacity={layer.opacity} />
      ))}
      {deployed &&
        sandbags.map((pts, i) => (
          <Line key={i} points={pts} color="#e0533d" lineWidth={6} transparent opacity={0.85 * layer.opacity} />
        ))}
    </group>
  );
}

export function Roads() {
  const visible = useStore((s) => s.layers.roads.visible);
  const roads = useMemo(() => ROADS.map((r) => drape(r, 1.8)), []);
  if (!visible) return null;
  return (
    <group>
      {roads.map((pts, i) => (
        <group key={i}>
          <Line points={pts} color="#8d8676" lineWidth={4.5} />
          <Line points={pts} color="#f4f1ea" lineWidth={2.5} />
        </group>
      ))}
    </group>
  );
}

export function AdminBoundaries() {
  const visible = useStore((s) => s.layers.admin.visible);
  const pts = useMemo(() => drape(ADMIN_BOUNDARY, 3), []);
  if (!visible) return null;
  return <Line points={pts} color="#7d6fa0" lineWidth={1.6} dashed dashSize={80} gapSize={50} />;
}
