import { useEffect, useMemo } from 'react';
import * as THREE from 'three';
import { candidates, computeDepths } from '../data/flood';
import { N, heights } from '../data/terrain';
import { depthLUT, lutIndex } from '../lib/floodColor';
import { useStore } from '../state/store';
import { gridPositions, sharedIndex } from './Terrain';

const DRY_DROP = 5; // dry vertices sink under the terrain so shorelines taper naturally

export function Water() {
  const layer = useStore((s) => s.layers.depth);

  const { geometry, update } = useMemo(() => {
    const pos = gridPositions(-DRY_DROP);
    const col = new Float32Array(N * N * 4);
    const nrm = new Float32Array(N * N * 3);
    for (let i = 0; i < N * N; i++) nrm[i * 3 + 1] = 1;
    const g = new THREE.BufferGeometry();
    const posAttr = new THREE.BufferAttribute(pos, 3);
    const colAttr = new THREE.BufferAttribute(col, 4);
    g.setAttribute('position', posAttr);
    g.setAttribute('color', colAttr);
    g.setAttribute('normal', new THREE.BufferAttribute(nrm, 3));
    g.setIndex(sharedIndex);

    const depth = new Float32Array(candidates.length);
    const fade = new Float32Array(candidates.length);
    const update = (t: number) => {
      computeDepths(t, depth, fade);
      for (let k = 0; k < candidates.length; k++) {
        const i = candidates[k];
        const dd = depth[k];
        if (dd > 0.03) {
          pos[i * 3 + 1] = heights[i] + dd + 0.15;
          const li = lutIndex(dd);
          col[i * 4] = depthLUT[li];
          col[i * 4 + 1] = depthLUT[li + 1];
          col[i * 4 + 2] = depthLUT[li + 2];
          col[i * 4 + 3] = depthLUT[li + 3] * fade[k];
        } else {
          pos[i * 3 + 1] = heights[i] - DRY_DROP;
          col[i * 4 + 3] = 0;
        }
      }
      posAttr.needsUpdate = true;
      colAttr.needsUpdate = true;
    };
    return { geometry: g, update };
  }, []);

  // Driven straight from the store, outside React rendering.
  useEffect(() => {
    update(useStore.getState().currentTime);
    return useStore.subscribe((s, prev) => {
      if (s.currentTime !== prev.currentTime) update(s.currentTime);
    });
  }, [update]);

  return (
    <mesh geometry={geometry} visible={layer.visible} renderOrder={3} frustumCulled={false}>
      <meshStandardMaterial
        vertexColors
        transparent
        opacity={layer.opacity}
        depthWrite={false}
        roughness={0.25}
        metalness={0.1}
      />
    </mesh>
  );
}
