import { useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { fbm, mulberry32 } from '../lib/noise';
import { LEVEE_D, N, SPACING, VEX, gridX, gridZ, hillFactor, sampleHeight, signedD } from '../data/terrain';
import { useStore } from '../state/store';

const GREENS = ['#4f6b3a', '#5d7a43', '#3f5a33', '#6b8048', '#56703c'].map((c) => new THREE.Color(c));

interface Tree {
  x: number;
  z: number;
  r: number;
  h: number;
  c: number;
}

function scatterTrees(): Tree[] {
  const rng = mulberry32(7);
  const trees: Tree[] = [];
  for (let i = 0; i < N * N && trees.length < 30000; i++) {
    const x = gridX(i % N);
    const z = gridZ(Math.floor(i / N));
    const d = signedD[i];
    const ad = Math.abs(d);
    const t = hillFactor(d);
    const forest = fbm(x / 900, z / 900, 3, 9);
    let p = forest > 0.44 ? 0.85 * t : 0.12 * t;
    // Riparian strip along the banks, but not on the levee.
    if (ad > 70 && ad < 230 && !(d > LEVEE_D - 30 && d < LEVEE_D + 40)) p = Math.max(p, 0.35);
    if (rng() > p) continue;
    const jx = x + (rng() - 0.5) * SPACING;
    const jz = z + (rng() - 0.5) * SPACING;
    trees.push({ x: jx, z: jz, r: 13 + rng() * 8, h: 42 + rng() * 26, c: Math.floor(rng() * GREENS.length) });
  }
  return trees;
}

export function Vegetation() {
  const visible = useStore((s) => s.layers.terrain.visible);
  const ref = useRef<THREE.InstancedMesh>(null);
  const trees = useMemo(scatterTrees, []);
  const geometry = useMemo(() => new THREE.ConeGeometry(1, 1, 6).translate(0, 0.5, 0), []);

  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    trees.forEach((t, i) => {
      m.compose(
        new THREE.Vector3(t.x, sampleHeight(t.x, t.z) - 1, t.z),
        q,
        new THREE.Vector3(t.r, t.h / VEX, t.r),
      );
      mesh.setMatrixAt(i, m);
      mesh.setColorAt(i, GREENS[t.c]);
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [trees]);

  return (
    <instancedMesh ref={ref} args={[geometry, undefined, trees.length]} visible={visible} frustumCulled={false}>
      <meshStandardMaterial flatShading roughness={0.9} />
    </instancedMesh>
  );
}
