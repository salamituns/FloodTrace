import { useFrame } from '@react-three/fiber';
import { useMemo } from 'react';
import * as THREE from 'three';
import { candidates, depthAt, flowVelocity, type FlowSample } from '../data/flood';
import { N, gridX, gridZ, sampleHeight } from '../data/terrain';
import { mulberry32 } from '../lib/noise';
import { useStore } from '../state/store';

const P = 700; // particles
const K = 10; // trail points per particle
const VIS = 110; // visual speed-up: 1 m/s of flow → 110 m per real second

export function FlowVectors() {
  const layer = useStore((s) => s.layers.flow);

  const sim = useMemo(() => {
    const rng = mulberry32(99);
    const px = new Float32Array(P * K);
    const pz = new Float32Array(P * K);
    const py = new Float32Array(P * K);
    const age = new Float32Array(P);
    const life = new Float32Array(P);
    const pos = new Float32Array(P * (K - 1) * 2 * 3);
    const col = new Float32Array(P * (K - 1) * 2 * 4);
    const g = new THREE.BufferGeometry();
    const posAttr = new THREE.BufferAttribute(pos, 3);
    const colAttr = new THREE.BufferAttribute(col, 4);
    g.setAttribute('position', posAttr);
    g.setAttribute('color', colAttr);
    const sample: FlowSample = { vx: 0, vz: 0, depth: 0 };

    const respawn = (p: number, t: number) => {
      for (let tries = 0; tries < 10; tries++) {
        const i = candidates[Math.floor(rng() * candidates.length)];
        const x = gridX(i % N) + (rng() - 0.5) * 30;
        const z = gridZ(Math.floor(i / N)) + (rng() - 0.5) * 30;
        if (depthAt(x, z, t) > 0.1) {
          const y = sampleHeight(x, z) + depthAt(x, z, t) + 1.5;
          for (let k = 0; k < K; k++) {
            px[p * K + k] = x;
            pz[p * K + k] = z;
            py[p * K + k] = y;
          }
          age[p] = 0;
          life[p] = 1.5 + rng() * 2.5;
          return;
        }
      }
      age[p] = life[p] = 0; // try again next frame
    };

    const step = (dt: number, t: number, opacity: number) => {
      for (let p = 0; p < P; p++) {
        const o = p * K;
        age[p] += dt;
        if (age[p] >= life[p] || !flowVelocity(px[o], pz[o], t, sample)) {
          respawn(p, t);
        } else {
          for (let k = K - 1; k > 0; k--) {
            px[o + k] = px[o + k - 1];
            pz[o + k] = pz[o + k - 1];
            py[o + k] = py[o + k - 1];
          }
          px[o] += sample.vx * VIS * dt;
          pz[o] += sample.vz * VIS * dt;
          py[o] = sampleHeight(px[o], pz[o]) + sample.depth + 1.5;
        }
        const fadeLife = Math.min(1, age[p] / 0.4, Math.max(0, (life[p] - age[p]) / 0.4));
        for (let k = 0; k < K - 1; k++) {
          const v = (p * (K - 1) + k) * 2;
          for (let e = 0; e < 2; e++) {
            const j = (v + e) * 3;
            pos[j] = px[o + k + e];
            pos[j + 1] = py[o + k + e];
            pos[j + 2] = pz[o + k + e];
            const c = (v + e) * 4;
            col[c] = 0.97;
            col[c + 1] = 0.98;
            col[c + 2] = 1;
            col[c + 3] = (1 - (k + e) / K) * fadeLife * opacity;
          }
        }
      }
      posAttr.needsUpdate = true;
      colAttr.needsUpdate = true;
    };
    return { geometry: g, step };
  }, []);

  useFrame((_, delta) => {
    if (!layer.visible) return;
    sim.step(Math.min(delta, 0.05), useStore.getState().currentTime, layer.opacity);
  });

  return (
    <lineSegments geometry={sim.geometry} visible={layer.visible} frustumCulled={false} renderOrder={5}>
      <lineBasicMaterial vertexColors transparent depthWrite={false} />
    </lineSegments>
  );
}
