import { Html, Line } from '@react-three/drei';
import { useMemo } from 'react';
import { HALF } from '../data/terrain';
import { fmtLat, fmtLon, latOf, lonOf, xOfLon, zOfLat } from '../lib/geo';

const STEP_DEG = 1 / 60; // one arc-minute
const Y = 900; // above the highest terrain; the 2D camera looks straight down

/** Lat/long graticule shown in the top-down 2D view. */
export function Grid2D() {
  const { lons, lats } = useMemo(() => {
    const lons: number[] = [];
    const lats: number[] = [];
    for (let lon = Math.ceil(lonOf(-HALF) / STEP_DEG) * STEP_DEG; lon < lonOf(HALF); lon += STEP_DEG) lons.push(lon);
    for (let lat = Math.ceil(latOf(HALF) / STEP_DEG) * STEP_DEG; lat < latOf(-HALF); lat += STEP_DEG) lats.push(lat);
    return { lons, lats };
  }, []);

  return (
    <group>
      {lons.map((lon) => {
        const x = xOfLon(lon);
        return (
          <group key={`lon${lon}`}>
            <Line points={[[x, Y, -HALF], [x, Y, HALF]]} color="#7c756a" lineWidth={0.8} transparent opacity={0.35} />
            <Html position={[x, Y, -2400]} center zIndexRange={[15, 0]} style={{ pointerEvents: 'none' }}>
              <div className="graticule">{fmtLon(lon)}</div>
            </Html>
          </group>
        );
      })}
      {lats.map((lat) => {
        const z = zOfLat(lat);
        return (
          <group key={`lat${lat}`}>
            <Line points={[[-HALF, Y, z], [HALF, Y, z]]} color="#7c756a" lineWidth={0.8} transparent opacity={0.35} />
            <Html position={[3200, Y, z]} center zIndexRange={[15, 0]} style={{ pointerEvents: 'none' }}>
              <div className="graticule">{fmtLat(lat)}</div>
            </Html>
          </group>
        );
      })}
    </group>
  );
}
