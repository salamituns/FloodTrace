import { create } from 'zustand';
import { QUANT, T0, T1, tAtHour } from '../lib/time';

export type LayerId =
  | 'terrain'
  | 'imagery'
  | 'maxExtent'
  | 'depth'
  | 'susceptibility'
  | 'flow'
  | 'defenses'
  | 'structures'
  | 'roads'
  | 'admin';

export interface LayerState {
  visible: boolean;
  opacity: number;
}

export const LAYER_DEFS: { id: LayerId; label: string; swatch: string; hasOpacity: boolean }[] = [
  { id: 'terrain', label: 'Terrain (3D)', swatch: 'linear-gradient(135deg,#8c9a63,#c2ab80 60%,#9b8761)', hasOpacity: true },
  { id: 'imagery', label: 'Aerial Imagery', swatch: 'repeating-linear-gradient(45deg,#a7a774 0 4px,#c4b88c 4px 8px)', hasOpacity: true },
  { id: 'maxExtent', label: 'Max Flood Extent', swatch: 'linear-gradient(135deg,#9db6c8,#6d8fa8)', hasOpacity: true },
  { id: 'depth', label: 'Flood Depth (Modeled)', swatch: 'linear-gradient(135deg,#8fc1e3,#1d4f7a)', hasOpacity: true },
  { id: 'susceptibility', label: 'Flood Susceptibility', swatch: 'radial-gradient(circle,#d64a3a,#e8893a 55%,#e9c45a)', hasOpacity: true },
  { id: 'flow', label: 'Flow Vectors', swatch: 'repeating-linear-gradient(160deg,#cfe0ec 0 2px,#7fa3bf 2px 5px)', hasOpacity: true },
  { id: 'defenses', label: 'Defenses (Levees & Sandbags)', swatch: 'linear-gradient(90deg,#7a5a3a 0 50%,#e0533d 50%)', hasOpacity: true },
  { id: 'structures', label: 'Structures', swatch: 'repeating-conic-gradient(#ece6da 0 25%,#b9b1a2 0 50%) 0 0/8px 8px', hasOpacity: false },
  { id: 'roads', label: 'Roads', swatch: 'linear-gradient(120deg,#ddd 45%,#9a9385 45% 55%,#ddd 55%)', hasOpacity: false },
  { id: 'admin', label: 'Administrative Boundaries', swatch: 'repeating-linear-gradient(90deg,#7d6fa0 0 3px,#eee 3px 6px)', hasOpacity: false },
];

export const SPEEDS = [1, 2, 4, 8]; // sim hours per real second

interface AppState {
  currentTime: number;
  playing: boolean;
  speed: number;
  viewMode: '2d' | '3d';
  layers: Record<LayerId, LayerState>;
  selectedEventId: string | null;
  setTime: (t: number) => void;
  setPlaying: (p: boolean) => void;
  togglePlay: () => void;
  cycleSpeed: () => void;
  setViewMode: (m: '2d' | '3d') => void;
  setLayer: (id: LayerId, patch: Partial<LayerState>) => void;
  selectEvent: (id: string | null) => void;
}

const clampT = (t: number) => Math.min(T1, Math.max(T0, t));

export const useStore = create<AppState>()((set) => ({
  currentTime: tAtHour(34), // Mar 4 16:00 — town flooding, river still rising
  playing: false,
  speed: 1,
  viewMode: '3d',
  layers: {
    terrain: { visible: true, opacity: 1 },
    imagery: { visible: true, opacity: 1 },
    maxExtent: { visible: true, opacity: 0.35 },
    depth: { visible: true, opacity: 0.9 },
    susceptibility: { visible: false, opacity: 0.7 },
    flow: { visible: false, opacity: 0.7 },
    defenses: { visible: true, opacity: 1 },
    structures: { visible: true, opacity: 1 },
    roads: { visible: false, opacity: 1 },
    admin: { visible: false, opacity: 1 },
  },
  selectedEventId: null,
  setTime: (t) => set({ currentTime: clampT(t) }),
  setPlaying: (playing) => set({ playing }),
  togglePlay: () =>
    set((s) => (s.playing ? { playing: false } : { playing: true, currentTime: s.currentTime >= T1 ? T0 : s.currentTime })),
  cycleSpeed: () => set((s) => ({ speed: SPEEDS[(SPEEDS.indexOf(s.speed) + 1) % SPEEDS.length] })),
  setViewMode: (viewMode) => set({ viewMode }),
  setLayer: (id, patch) => set((s) => ({ layers: { ...s.layers, [id]: { ...s.layers[id], ...patch } } })),
  selectEvent: (selectedEventId) => set({ selectedEventId }),
}));

/** Time snapped to 15 min — for panels that shouldn't re-render every frame during playback. */
export const useQuantTime = () => useStore((s) => Math.floor(s.currentTime / QUANT) * QUANT);

/** Camera readouts written by the scene, read by the map overlay controls. */
export const useViewStore = create<{ zoom: number; azimuth: number }>()(() => ({ zoom: 2, azimuth: 0 }));
